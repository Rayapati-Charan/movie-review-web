# Movie-Rating-Web
 A React WebPagge to Rate and Review Movies
# Server 
 1)npm init
 2)npm install express --save
 3)npm install nodemon
 4)npm install cors axios
 5)npm install --save express-session body-parser cookie-parser 


# client 
 1) React app
 2) npm install 
 3)npm install react-router-dom
  4)npm install react-bootstrap bootstrap
 5)npm install --save react-fontawesome
  6)npm install redux redux-react-session --save
