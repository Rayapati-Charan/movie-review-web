import '../Component/mystyle.css'

export default function Footer() {
    return (
        <div class="container-fluid bg foot">
      <footer class="site-footer">
        
        <h5 class="footer-style">
          Rating My Movie.com | Developed by&nbsp;
          <a 
            class="text-warning text-decoration-none"
            href="https://www.linkedin.com/in/charan-rayapati-b773a6223"
            target="blank"
          >
            Rayapati Charan
          </a>
        </h5>
      </footer>
    </div>
    )
}